package com.example.mandarspring2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MandarSpring2Application {

    public static void main(String[] args) {
        SpringApplication.run(MandarSpring2Application.class, args);
    }

}
